import csv
from datetime import datetime 
from matplotlib import pyplot as plt
from numpy import min_scalar_type 
filename = 'laporan_iklim_harian_dki_jan_2019.csv'
with open (filename) as f:
    reader = csv.reader(f)
    header_row = next(reader)

    tanggal, maximum, minimum = [], [], []
    for row in reader :
        current_date = datetime.strptime(row[0], '%d-%m-%Y')
        max = float(row[2])
        min = float(row[1])
        tanggal.append(current_date)
        maximum.append(max)
        minimum.append(min)

# plot and shade 
plt.style.use('seaborn')
fig, ax = plt.subplots()
ax.plot(tanggal, maximum, c='red')
ax.plot(tanggal, minimum, c='blue')
plt.fill_between(tanggal, maximum, minimum, facecolor='grey', alpha = 0.5)

#format 
plt.title("Iklim harian DKI 2019", fontsize=24)
plt.xlabel('', fontsize=12)
fig.autofmt_xdate()
plt.ylabel('suhu (c)', fontsize=12)
plt.tick_params(axis='both', which='major', labelsize = 12)
plt.ylim(20, 40)
plt.show